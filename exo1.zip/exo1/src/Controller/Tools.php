<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController as ControllerAbstractController;
use Symfony\Component\HttpFoundation\Response;
use symfony\Component\Routing\Annotation\Route;

class Tools extends ControllerAbstractController
{
    #[Route("/", name:"Acceuil")]
    public function bet(): Response
    {
        return $this->render('first.html.twig');
    }

    #[Route("/Tools", name:"Insertion")]
    public function form(): Response
    {
        return $this->render('form.html.twig');
    }

    #[Route("/Tab", name:"Resultats")]
    public function tab(): Response
    {
        return $this->render('tab.html.twig');
    }
}
?>