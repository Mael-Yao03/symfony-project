<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* form.html.twig */
class __TwigTemplate_03aa8a586c71c43395f2ed29f115a736 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "form.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "form.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Inscription";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "
<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Enregistrement</title>
</head>
<style>

body {
    background-color: rgb(14, 100, 238);
  
    align-items: center;
    justify-content: center;
    min-height: 100vh; /* Utilisation de min-height pour que le fond s'étende sur toute la vue */
    margin: 0;
}

form {
    width: 100%; /* Le formulaire occupe toute la largeur */
    max-width: 400px; /* Limite la largeur maximale du formulaire */
    padding: 15px; /* Réduction du padding pour réduire la hauteur du formulaire */
    border: 1px solid #ccc;
    background-color: rgb(11, 11, 11);
    border-radius: 30px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
    color: white;
    margin: auto; /* Centre le formulaire horizontalement */
}

/* Styles pour les étiquettes */
label {
    display: inline-block;
    width: 100px;
    font-weight: bold;
    margin-bottom: 5px;
}

/* Styles pour les champs de texte et les boîtes de sélection */
input[type=\"text\"],
input[type=\"date\"],
select {
    width: 100%; /* Les champs occupent toute la largeur */
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #0e0d0d;
    border-radius: 4px;
}

/* Styles pour les boutons d'envoi et de réinitialisation */
input[type=\"submit\"],
input[type=\"reset\"] {
    background-color: rgb(115, 115, 113);
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 20px;
}

input[type=\"reset\"] {
    background-color: rgb(115, 115, 113);
}

/* Effacement du flot après les éléments du formulaire */
form::after {
    content: \"\";
    display: table;
    clear: both;
}

/* Ajustements pour la conception responsive */
@media (max-width: 400px) {
    form {
        width: 100%;
    }
}
J'ai modifié le code en réduisant le padding du formulaire pour réduire sa hauteur. En outre, j'ai utilisé min-height pour le corps (body) afin que le fond s'étende sur au moins la hauteur de la vue, même si le contenu est court. Le reste des styles reste inchangé.

Cela devrait centrer le formulaire horizontalement et verticalement tout en réduisant sa hauteur.








</style>


<body>

    <form action=\"\">
        <label for=\"nom\">Nom:</label>
        <input type=\"text\" name=\"nom\" required><br>

        <label for=\"prenom\">Prenom:</label>
        <input type=\"text\" name=\"prenom\" required><br>

        <label for=\"date de naissance\">Date de Naissance:</label>
        <input type=\"date\" name=\"date de naissance\" required><br>

        <label for=\"niveau scolaire\">Niveau scolaire:</label>
        <select name=\"niveau scolaire\" id=\"niveau scolaire\" required>
            <option value=\"\" disabled selected>Veuillez choisir</option>
            <option value=\"primaire\">Primaire</option>
            <option value=\"secondaire\">Secondaire</option>
            <option value=\"supérieur\">Supérieur</option>
        </select><br>

        <label for=\"module choisit\">Module choisit:</label>
        <select name=\"module choisit\" id=\"module choisit\" required>
            <option value=\"\"disabled selected>Veuillez choisir</option>
            <option value=\"JavaScript\">JavaScript</option>
            <option value=\"Python\">Python</option>
            <option value=\"PHP\">PHP</option>
        </select><br>

        <label for=\"motif d'inscription\">Motif d'inscription</label>
        <input type=\"text\" name=\"motif d'inscription\" required><br><br>

        <input type=\"reset\" name=\"supprimer\" value=\"Supprimer\">
        <input type=\"submit\" name=\"envoyer\" value=\"Envoyer\">


    </form>
    
</body>
</html>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    public function getTemplateName()
    {
        return "form.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Inscription{% endblock %}

{% block body %}

<!DOCTYPE html>
<html lang=\"en\">
<head>
    <meta charset=\"UTF-8\">
    <title>Enregistrement</title>
</head>
<style>

body {
    background-color: rgb(14, 100, 238);
  
    align-items: center;
    justify-content: center;
    min-height: 100vh; /* Utilisation de min-height pour que le fond s'étende sur toute la vue */
    margin: 0;
}

form {
    width: 100%; /* Le formulaire occupe toute la largeur */
    max-width: 400px; /* Limite la largeur maximale du formulaire */
    padding: 15px; /* Réduction du padding pour réduire la hauteur du formulaire */
    border: 1px solid #ccc;
    background-color: rgb(11, 11, 11);
    border-radius: 30px;
    box-shadow: 0px 0px 5px rgba(0, 0, 0, 0.2);
    color: white;
    margin: auto; /* Centre le formulaire horizontalement */
}

/* Styles pour les étiquettes */
label {
    display: inline-block;
    width: 100px;
    font-weight: bold;
    margin-bottom: 5px;
}

/* Styles pour les champs de texte et les boîtes de sélection */
input[type=\"text\"],
input[type=\"date\"],
select {
    width: 100%; /* Les champs occupent toute la largeur */
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #0e0d0d;
    border-radius: 4px;
}

/* Styles pour les boutons d'envoi et de réinitialisation */
input[type=\"submit\"],
input[type=\"reset\"] {
    background-color: rgb(115, 115, 113);
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    margin-right: 20px;
}

input[type=\"reset\"] {
    background-color: rgb(115, 115, 113);
}

/* Effacement du flot après les éléments du formulaire */
form::after {
    content: \"\";
    display: table;
    clear: both;
}

/* Ajustements pour la conception responsive */
@media (max-width: 400px) {
    form {
        width: 100%;
    }
}
J'ai modifié le code en réduisant le padding du formulaire pour réduire sa hauteur. En outre, j'ai utilisé min-height pour le corps (body) afin que le fond s'étende sur au moins la hauteur de la vue, même si le contenu est court. Le reste des styles reste inchangé.

Cela devrait centrer le formulaire horizontalement et verticalement tout en réduisant sa hauteur.








</style>


<body>

    <form action=\"\">
        <label for=\"nom\">Nom:</label>
        <input type=\"text\" name=\"nom\" required><br>

        <label for=\"prenom\">Prenom:</label>
        <input type=\"text\" name=\"prenom\" required><br>

        <label for=\"date de naissance\">Date de Naissance:</label>
        <input type=\"date\" name=\"date de naissance\" required><br>

        <label for=\"niveau scolaire\">Niveau scolaire:</label>
        <select name=\"niveau scolaire\" id=\"niveau scolaire\" required>
            <option value=\"\" disabled selected>Veuillez choisir</option>
            <option value=\"primaire\">Primaire</option>
            <option value=\"secondaire\">Secondaire</option>
            <option value=\"supérieur\">Supérieur</option>
        </select><br>

        <label for=\"module choisit\">Module choisit:</label>
        <select name=\"module choisit\" id=\"module choisit\" required>
            <option value=\"\"disabled selected>Veuillez choisir</option>
            <option value=\"JavaScript\">JavaScript</option>
            <option value=\"Python\">Python</option>
            <option value=\"PHP\">PHP</option>
        </select><br>

        <label for=\"motif d'inscription\">Motif d'inscription</label>
        <input type=\"text\" name=\"motif d'inscription\" required><br><br>

        <input type=\"reset\" name=\"supprimer\" value=\"Supprimer\">
        <input type=\"submit\" name=\"envoyer\" value=\"Envoyer\">


    </form>
    
</body>
</html>

{% endblock %}", "form.html.twig", "C:\\xampp\\htdocs\\GLAB\\exo\\templates\\form.html.twig");
    }
}
